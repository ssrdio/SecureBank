﻿using Microsoft.AspNetCore.Mvc;

namespace SecureBank.Controllers
{
    [ApiExplorerSettings(IgnoreApi = true)]
    public class MvcBaseContoller : Controller
    {
    }
}
