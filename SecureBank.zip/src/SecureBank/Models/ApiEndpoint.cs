﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SecureBank.Models
{
    public class ApiEndpoint
    {
        public string ApiUrl { get; set; }
        public string ApiToken { get; set; }
    }
}
