﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SecureBank.Models.User
{
    public class UserInfoReq
    {
        public string UserName { get; set; }
    }
}
