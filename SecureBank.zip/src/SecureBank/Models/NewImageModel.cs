﻿namespace SecureBank.Models
{
    public class NewImageModel
    {
        public string Username { get; set; }
        public string ImageUrl { get; set; }
    }
}
