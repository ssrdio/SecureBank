#!/bin/bash

./maildev/bin/maildev